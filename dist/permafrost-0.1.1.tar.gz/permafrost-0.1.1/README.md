# Permafrost

`Permafrost` is a library that gets emails by the company name, verifies if the email exist, then creates a csv file in the current location.